
import time
import torch


def train_one_epoch(
    model,
    dataloader,
    optimizer,
    criterion,
    metrics,
    device
):
    """Train a semantic segmentation model for one epoch."""

    model.train()
    metrics.reset()

    running_loss = 0.0
    num_batches = 0

    for images, masks, _ in dataloader:

        images = images.to(device, non_blocking=True)
        masks = masks.to(device, non_blocking=True)

        optimizer.zero_grad(set_to_none=True)

        outputs = model(images)

        loss = criterion(outputs, masks)

        loss.backward()

        optimizer.step()

        running_loss += loss.item()
        num_batches += 1

        metrics.update(
            outputs.detach(),
            masks
        )

    results = metrics.compute()

    return {
        "loss": running_loss / max(num_batches, 1),
        "miou": results["miou"],
        "dice": results["dice"],
        "pixel_accuracy": results["pixel_accuracy"],
        "precision": results["precision"],
        "recall": results["recall"]
    }


@torch.no_grad()
def validate_one_epoch(
    model,
    dataloader,
    criterion,
    metrics,
    device
):
    """Validate a semantic segmentation model."""

    model.eval()
    metrics.reset()

    running_loss = 0.0
    num_batches = 0

    for images, masks, _ in dataloader:

        images = images.to(device, non_blocking=True)
        masks = masks.to(device, non_blocking=True)

        outputs = model(images)

        loss = criterion(outputs, masks)

        running_loss += loss.item()
        num_batches += 1

        metrics.update(
            outputs,
            masks
        )

    results = metrics.compute()

    return {
        "loss": running_loss / max(num_batches, 1),
        "miou": results["miou"],
        "dice": results["dice"],
        "pixel_accuracy": results["pixel_accuracy"],
        "precision": results["precision"],
        "recall": results["recall"]
    }


def train_model(
    model,
    train_loader,
    val_loader,
    optimizer,
    criterion,
    train_metrics,
    val_metrics,
    epochs,
    device,
    checkpoint_path=None
):
    """
    Complete semantic segmentation training interface.

    Best checkpoint is selected using validation mIoU.
    """

    history = []

    best_val_miou = -1.0
    best_epoch = 0

    total_start = time.perf_counter()

    for epoch in range(1, epochs + 1):

        if torch.cuda.is_available():
            torch.cuda.reset_peak_memory_stats()

        epoch_start = time.perf_counter()

        train_results = train_one_epoch(
            model,
            train_loader,
            optimizer,
            criterion,
            train_metrics,
            device
        )

        val_results = validate_one_epoch(
            model,
            val_loader,
            criterion,
            val_metrics,
            device
        )

        epoch_time = time.perf_counter() - epoch_start

        learning_rate = optimizer.param_groups[0]["lr"]

        if torch.cuda.is_available():
            peak_memory_mb = (
                torch.cuda.max_memory_allocated()
                / (1024 ** 2)
            )
        else:
            peak_memory_mb = 0.0

        record = {
            "epoch": epoch,

            "train_loss": train_results["loss"],
            "train_miou": train_results["miou"],
            "train_dice": train_results["dice"],

            "val_loss": val_results["loss"],
            "val_miou": val_results["miou"],
            "val_dice": val_results["dice"],

            "learning_rate": learning_rate,
            "epoch_time_seconds": epoch_time,
            "peak_gpu_memory_mb": peak_memory_mb
        }

        history.append(record)

        print(
            f"Epoch {epoch:02d}/{epochs} | "
            f"Train Loss: {train_results['loss']:.4f} | "
            f"Val Loss: {val_results['loss']:.4f} | "
            f"Train mIoU: {train_results['miou']:.4f} | "
            f"Val mIoU: {val_results['miou']:.4f} | "
            f"Val Dice: {val_results['dice']:.4f} | "
            f"Time: {epoch_time:.1f}s"
        )

        # Save BEST checkpoint based ONLY on validation mIoU
        if val_results["miou"] > best_val_miou:

            best_val_miou = val_results["miou"]
            best_epoch = epoch

            if checkpoint_path is not None:

                torch.save(
                    {
                        "epoch": epoch,
                        "model_state_dict": model.state_dict(),
                        "optimizer_state_dict": optimizer.state_dict(),
                        "val_miou": best_val_miou,
                        "history": history
                    },
                    checkpoint_path
                )

        # Save LATEST checkpoint after every completed epoch
        # Used only to recover from an interrupted training run.
        if checkpoint_path is not None:

            latest_path = checkpoint_path.replace(
                "_best.pth",
                "_latest.pth"
            )

            torch.save(
                {
                    "epoch": epoch,
                    "model_state_dict": model.state_dict(),
                    "optimizer_state_dict": optimizer.state_dict(),
                    "val_miou": val_results["miou"],
                    "best_val_miou": best_val_miou,
                    "best_epoch": best_epoch,
                    "history": history
                },
                latest_path
            )

    total_training_time = (
        time.perf_counter() - total_start
    )

    return {
        "history": history,
        "best_val_miou": best_val_miou,
        "best_epoch": best_epoch,
        "total_training_time_seconds": total_training_time
    }
