
import torch
import torch.nn as nn
import torch.nn.functional as F


IGNORE_INDEX = 255


class DiceLoss(nn.Module):
    """
    Multi-class Dice loss.

    Background is included in the macro average.
    Pixels labeled 255 are ignored.
    """

    def __init__(
        self,
        num_classes=6,
        ignore_index=IGNORE_INDEX,
        smooth=1e-6,
    ):
        super().__init__()

        self.num_classes = num_classes
        self.ignore_index = ignore_index
        self.smooth = smooth

    def forward(self, logits, targets):

        probabilities = F.softmax(logits, dim=1)

        # Valid pixels exclude ignore_index.
        valid = targets != self.ignore_index

        # Replace ignored labels temporarily so one_hot is valid.
        safe_targets = targets.clone()
        safe_targets[~valid] = 0

        one_hot = F.one_hot(
            safe_targets,
            num_classes=self.num_classes,
        ).permute(0, 3, 1, 2).float()

        valid = valid.unsqueeze(1).float()

        probabilities = probabilities * valid
        one_hot = one_hot * valid

        intersection = (
            probabilities * one_hot
        ).sum(dim=(0, 2, 3))

        denominator = (
            probabilities.sum(dim=(0, 2, 3))
            + one_hot.sum(dim=(0, 2, 3))
        )

        dice = (
            (2.0 * intersection + self.smooth)
            / (denominator + self.smooth)
        )

        return 1.0 - dice.mean()


class CombinedSegmentationLoss(nn.Module):
    """
    Required semantic loss:

    0.5 * CrossEntropyLoss
    +
    0.5 * DiceLoss
    """

    def __init__(
        self,
        num_classes=6,
        ignore_index=IGNORE_INDEX,
    ):
        super().__init__()

        self.cross_entropy = nn.CrossEntropyLoss(
            ignore_index=ignore_index
        )

        self.dice = DiceLoss(
            num_classes=num_classes,
            ignore_index=ignore_index,
        )

    def forward(self, logits, targets):

        ce_loss = self.cross_entropy(
            logits,
            targets
        )

        dice_loss = self.dice(
            logits,
            targets
        )

        return (
            0.5 * ce_loss
            + 0.5 * dice_loss
        )
