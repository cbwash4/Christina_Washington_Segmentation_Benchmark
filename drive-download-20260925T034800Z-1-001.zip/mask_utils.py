"""
Mask utilities for the CCIS 727 Image Segmentation Benchmark.

Converts COCO instance annotations into semantic segmentation masks
using the benchmark's documented class and ignore-region policy.
"""

import numpy as np


# COCO category ID -> benchmark semantic class ID
COCO_TO_BENCHMARK = {
    1: 1,    # person
    3: 2,    # car
    2: 3,    # bicycle
    18: 4,   # dog
    17: 5,   # cat
}

IGNORE_INDEX = 255


def create_semantic_mask(coco, image_id, ignore_index=IGNORE_INDEX):
    """
    Create a semantic segmentation mask for one COCO image.

    Output labels:
        0   background
        1   person
        2   car
        3   bicycle
        4   dog
        5   cat
        255 ignored pixel

    Policy:
    - Non-selected COCO classes remain background.
    - Same-class overlaps retain the semantic class.
    - Different selected-class overlaps become ignore_index.
    - Selected-class iscrowd regions become ignore_index.

    Parameters
    ----------
    coco:
        pycocotools COCO object.

    image_id:
        COCO image ID.

    ignore_index:
        Pixel value used for ignored regions.

    Returns
    -------
    numpy.ndarray
        H x W uint8 semantic mask.
    """

    image_info = coco.loadImgs([int(image_id)])[0]

    height = int(image_info["height"])
    width = int(image_info["width"])

    semantic_mask = np.zeros(
        (height, width),
        dtype=np.uint8
    )

    # Tracks selected-class occupancy independently from the final mask.
    # This allows different-class overlaps to be detected reliably.
    class_occupancy = np.zeros(
        (height, width),
        dtype=np.uint8
    )

    ann_ids = coco.getAnnIds(
        imgIds=[int(image_id)],
        catIds=list(COCO_TO_BENCHMARK.keys())
    )

    annotations = coco.loadAnns(ann_ids)

    # Process normal selected-class instances first.
    for ann in annotations:

        if ann.get("iscrowd", 0) == 1:
            continue

        coco_category = int(ann["category_id"])

        if coco_category not in COCO_TO_BENCHMARK:
            continue

        class_id = COCO_TO_BENCHMARK[coco_category]

        instance_mask = coco.annToMask(ann).astype(bool)

        if not instance_mask.any():
            continue

        existing_class = class_occupancy[instance_mask]

        # Pixels already occupied by a DIFFERENT selected class.
        conflict = (
            (existing_class != 0) &
            (existing_class != class_id)
        )

        # Pixels that have not yet been assigned a selected class.
        empty = (existing_class == 0)

        rows, cols = np.where(instance_mask)

        # Assign previously empty pixels to this class.
        empty_rows = rows[empty]
        empty_cols = cols[empty]

        class_occupancy[empty_rows, empty_cols] = class_id
        semantic_mask[empty_rows, empty_cols] = class_id

        # Different selected classes overlap here.
        conflict_rows = rows[conflict]
        conflict_cols = cols[conflict]

        semantic_mask[
            conflict_rows,
            conflict_cols
        ] = ignore_index

    # Crowd regions for selected classes are always ignored.
    for ann in annotations:

        if ann.get("iscrowd", 0) != 1:
            continue

        crowd_mask = coco.annToMask(ann).astype(bool)

        semantic_mask[crowd_mask] = ignore_index

    return semantic_mask


def get_mask_statistics(mask, ignore_index=IGNORE_INDEX):
    """
    Return pixel counts for each benchmark class and ignored pixels.
    """

    stats = {
        "background": int(np.sum(mask == 0)),
        "person": int(np.sum(mask == 1)),
        "car": int(np.sum(mask == 2)),
        "bicycle": int(np.sum(mask == 3)),
        "dog": int(np.sum(mask == 4)),
        "cat": int(np.sum(mask == 5)),
        "ignored": int(np.sum(mask == ignore_index)),
        "total": int(mask.size),
    }

    return stats
