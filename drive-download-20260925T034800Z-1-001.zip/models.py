
import torch.nn as nn
import segmentation_models_pytorch as smp

import torch.nn.functional as F
from transformers import (
    SegformerForSemanticSegmentation,
    SegformerConfig
)

from torchvision.models.segmentation import (
    fcn_resnet50,
    FCN_ResNet50_Weights,
    deeplabv3_resnet50,
    DeepLabV3_ResNet50_Weights
)


class FCNResNet50Wrapper(nn.Module):
    """
    FCN-ResNet50 adapted to the common benchmark interface.
    Returns [B, C, H, W].
    """

    def __init__(
        self,
        num_classes=6,
        pretrained=True
    ):
        super().__init__()

        weights = (
            FCN_ResNet50_Weights.DEFAULT
            if pretrained
            else None
        )

        self.model = fcn_resnet50(
            weights=weights
        )

        in_channels = self.model.classifier[4].in_channels

        self.model.classifier[4] = nn.Conv2d(
            in_channels,
            num_classes,
            kernel_size=1
        )

        if self.model.aux_classifier is not None:

            aux_in_channels = (
                self.model.aux_classifier[4].in_channels
            )

            self.model.aux_classifier[4] = nn.Conv2d(
                aux_in_channels,
                num_classes,
                kernel_size=1
            )

    def forward(self, x):
        return self.model(x)["out"]


class DeepLabV3ResNet50Wrapper(nn.Module):
    """
    DeepLabV3-ResNet50 adapted to the common benchmark interface.
    Returns [B, C, H, W].
    """

    def __init__(
        self,
        num_classes=6,
        pretrained=True
    ):
        super().__init__()

        weights = (
            DeepLabV3_ResNet50_Weights.DEFAULT
            if pretrained
            else None
        )

        self.model = deeplabv3_resnet50(
            weights=weights
        )

        in_channels = self.model.classifier[4].in_channels

        self.model.classifier[4] = nn.Conv2d(
            in_channels,
            num_classes,
            kernel_size=1
        )

        if self.model.aux_classifier is not None:

            aux_in_channels = (
                self.model.aux_classifier[4].in_channels
            )

            self.model.aux_classifier[4] = nn.Conv2d(
                aux_in_channels,
                num_classes,
                kernel_size=1
            )

    def forward(self, x):
        return self.model(x)["out"]


# ============================================================
# SEGNET
# ============================================================

class SegNet(nn.Module):
    """
    SegNet semantic segmentation architecture.

    Encoder max-pooling indices are reused by the decoder
    through MaxUnpool2d.

    Output:
        [B, num_classes, H, W]
    """

    def __init__(self, num_classes=6):
        super().__init__()

        # -------------------------
        # Encoder Block 1
        # -------------------------
        self.enc1 = nn.Sequential(
            nn.Conv2d(3, 64, 3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),

            nn.Conv2d(64, 64, 3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True)
        )

        # Encoder Block 2
        self.enc2 = nn.Sequential(
            nn.Conv2d(64, 128, 3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),

            nn.Conv2d(128, 128, 3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True)
        )

        # Encoder Block 3
        self.enc3 = nn.Sequential(
            nn.Conv2d(128, 256, 3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),

            nn.Conv2d(256, 256, 3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),

            nn.Conv2d(256, 256, 3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True)
        )

        # Encoder Block 4
        self.enc4 = nn.Sequential(
            nn.Conv2d(256, 512, 3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),

            nn.Conv2d(512, 512, 3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),

            nn.Conv2d(512, 512, 3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True)
        )

        # Encoder Block 5
        self.enc5 = nn.Sequential(
            nn.Conv2d(512, 512, 3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),

            nn.Conv2d(512, 512, 3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),

            nn.Conv2d(512, 512, 3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True)
        )

        self.pool = nn.MaxPool2d(
            kernel_size=2,
            stride=2,
            return_indices=True
        )

        self.unpool = nn.MaxUnpool2d(
            kernel_size=2,
            stride=2
        )

        # -------------------------
        # Decoder Block 5
        # -------------------------
        self.dec5 = nn.Sequential(
            nn.Conv2d(512, 512, 3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),

            nn.Conv2d(512, 512, 3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),

            nn.Conv2d(512, 512, 3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True)
        )

        # Decoder Block 4
        self.dec4 = nn.Sequential(
            nn.Conv2d(512, 512, 3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),

            nn.Conv2d(512, 512, 3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),

            nn.Conv2d(512, 256, 3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True)
        )

        # Decoder Block 3
        self.dec3 = nn.Sequential(
            nn.Conv2d(256, 256, 3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),

            nn.Conv2d(256, 256, 3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),

            nn.Conv2d(256, 128, 3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True)
        )

        # Decoder Block 2
        self.dec2 = nn.Sequential(
            nn.Conv2d(128, 128, 3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),

            nn.Conv2d(128, 64, 3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True)
        )

        # Decoder Block 1
        self.dec1 = nn.Sequential(
            nn.Conv2d(64, 64, 3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),

            nn.Conv2d(
                64,
                num_classes,
                3,
                padding=1
            )
        )


    def forward(self, x):

        # Encoder
        x1 = self.enc1(x)
        size1 = x1.size()
        x, idx1 = self.pool(x1)

        x2 = self.enc2(x)
        size2 = x2.size()
        x, idx2 = self.pool(x2)

        x3 = self.enc3(x)
        size3 = x3.size()
        x, idx3 = self.pool(x3)

        x4 = self.enc4(x)
        size4 = x4.size()
        x, idx4 = self.pool(x4)

        x5 = self.enc5(x)
        size5 = x5.size()
        x, idx5 = self.pool(x5)

        # Decoder
        x = self.unpool(
            x,
            idx5,
            output_size=size5
        )
        x = self.dec5(x)

        x = self.unpool(
            x,
            idx4,
            output_size=size4
        )
        x = self.dec4(x)

        x = self.unpool(
            x,
            idx3,
            output_size=size3
        )
        x = self.dec3(x)

        x = self.unpool(
            x,
            idx2,
            output_size=size2
        )
        x = self.dec2(x)

        x = self.unpool(
            x,
            idx1,
            output_size=size1
        )
        x = self.dec1(x)

        return x





# ============================================================
# SEGFORMER-B0
# ============================================================

class SegFormerB0Wrapper(nn.Module):
    """
    SegFormer-B0 adapted to the common benchmark interface.

    Native SegFormer logits are resized to the original
    input resolution.

    Output:
        [B, num_classes, H, W]
    """

    def __init__(
        self,
        num_classes=6,
        pretrained=True
    ):
        super().__init__()

        checkpoint = (
            "nvidia/segformer-b0-finetuned-ade-512-512"
        )

        if pretrained:

            self.model = (
                SegformerForSemanticSegmentation
                .from_pretrained(
                    checkpoint,
                    num_labels=num_classes,
                    ignore_mismatched_sizes=True
                )
            )

        else:

            config = SegformerConfig(
                num_labels=num_classes
            )

            self.model = (
                SegformerForSemanticSegmentation(
                    config
                )
            )


    def forward(self, x):

        input_size = x.shape[-2:]

        outputs = self.model(
            pixel_values=x
        )

        logits = outputs.logits

        logits = F.interpolate(
            logits,
            size=input_size,
            mode="bilinear",
            align_corners=False
        )

        return logits


def get_segmentation_model(
    model_name,
    num_classes=6,
    pretrained=True
):
    """
    Reusable semantic segmentation model factory.
    """

    model_name = model_name.lower()

    encoder_weights = (
        "imagenet" if pretrained else None
    )

    # FCN-RESNET50
    if model_name in [
        "fcn",
        "fcn_resnet50"
    ]:

        model = FCNResNet50Wrapper(
            num_classes=num_classes,
            pretrained=pretrained
        )

    # U-NET
    elif model_name == "unet":

        model = smp.Unet(
            encoder_name="resnet34",
            encoder_weights=encoder_weights,
            in_channels=3,
            classes=num_classes
        )

    # U-NET++
    elif model_name in [
        "unetplusplus",
        "unet++"
    ]:

        model = smp.UnetPlusPlus(
            encoder_name="resnet34",
            encoder_weights=encoder_weights,
            in_channels=3,
            classes=num_classes
        )

    # DEEPLABV3-RESNET50
    elif model_name in [
        "deeplabv3",
        "deeplabv3_resnet50"
    ]:

        model = DeepLabV3ResNet50Wrapper(
            num_classes=num_classes,
            pretrained=pretrained
        )

    # PSPNET
    elif model_name == "pspnet":

        model = smp.PSPNet(
            encoder_name="resnet34",
            encoder_weights=encoder_weights,
            in_channels=3,
            classes=num_classes
        )

    # SEGNET
    elif model_name == "segnet":

        model = SegNet(
            num_classes=num_classes
        )

    # SEGFORMER-B0
    elif model_name in [
        "segformer",
        "segformer_b0",
        "segformer-b0"
    ]:

        model = SegFormerB0Wrapper(
            num_classes=num_classes,
            pretrained=pretrained
        )

    else:

        raise ValueError(
            f"Unknown segmentation model: {model_name}"
        )

    return model


