
import random
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset
from torchvision.transforms import functional as TF
from torchvision.transforms import InterpolationMode


class COCOSemanticDataset(Dataset):
    """
    COCO semantic dataset for the segmentation benchmark.

    Images and masks are resized to 512x512.
    Training optionally uses horizontal flipping.
    """

    def __init__(
        self,
        image_dir,
        mask_dir,
        image_ids,
        image_size=512,
        training=False,
        horizontal_flip=True,
    ):
        self.image_dir = Path(image_dir)
        self.mask_dir = Path(mask_dir)
        self.image_ids = [int(x) for x in image_ids]
        self.image_size = image_size
        self.training = training
        self.horizontal_flip = horizontal_flip

    def __len__(self):
        return len(self.image_ids)

    def __getitem__(self, index):

        image_id = self.image_ids[index]

        image_path = (
            self.image_dir /
            f"{image_id:012d}.jpg"
        )

        mask_path = (
            self.mask_dir /
            f"{image_id:012d}.png"
        )

        image = Image.open(image_path).convert("RGB")
        mask = Image.open(mask_path)

        # Resize image using bilinear interpolation.
        image = TF.resize(
            image,
            [self.image_size, self.image_size],
            interpolation=InterpolationMode.BILINEAR,
        )

        # Resize discrete mask using nearest-neighbor interpolation.
        mask = TF.resize(
            mask,
            [self.image_size, self.image_size],
            interpolation=InterpolationMode.NEAREST,
        )

        # Simple training augmentation.
        if (
            self.training
            and self.horizontal_flip
            and random.random() < 0.5
        ):
            image = TF.hflip(image)
            mask = TF.hflip(mask)

        # Convert image to float tensor in [0, 1].
        image = TF.to_tensor(image)

        # ImageNet normalization for semantic CNN models.
        image = TF.normalize(
            image,
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225],
        )

        # Preserve integer class IDs including ignore label 255.
        mask = torch.from_numpy(
            np.array(mask, dtype=np.uint8).copy()
        ).long()

        return image, mask, image_id
