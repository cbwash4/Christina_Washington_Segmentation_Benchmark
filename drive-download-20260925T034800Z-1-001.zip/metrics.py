
import numpy as np
import torch


class SegmentationMetrics:
    """
    Accumulates a confusion matrix for semantic segmentation.

    Metrics:
    - Pixel accuracy
    - Per-class IoU
    - Mean IoU
    - Per-class Dice
    - Mean Dice
    - Precision
    - Recall

    Background is included in macro averages.
    Pixels labeled 255 are ignored.
    Classes absent from both ground truth and prediction are excluded
    from macro averages.
    """

    def __init__(
        self,
        num_classes=6,
        ignore_index=255,
    ):
        self.num_classes = num_classes
        self.ignore_index = ignore_index
        self.reset()

    def reset(self):
        self.confusion_matrix = np.zeros(
            (self.num_classes, self.num_classes),
            dtype=np.int64,
        )

    def update(self, predictions, targets):

        # Accept model logits [B, C, H, W]
        if isinstance(predictions, torch.Tensor):
            if predictions.ndim == 4:
                predictions = torch.argmax(
                    predictions,
                    dim=1
                )

            predictions = (
                predictions
                .detach()
                .cpu()
                .numpy()
            )

        if isinstance(targets, torch.Tensor):
            targets = (
                targets
                .detach()
                .cpu()
                .numpy()
            )

        predictions = np.asarray(predictions).reshape(-1)
        targets = np.asarray(targets).reshape(-1)

        # Remove ignored pixels and any invalid labels.
        valid = (
            (targets != self.ignore_index)
            & (targets >= 0)
            & (targets < self.num_classes)
            & (predictions >= 0)
            & (predictions < self.num_classes)
        )

        targets = targets[valid]
        predictions = predictions[valid]

        indices = (
            self.num_classes * targets
            + predictions
        )

        matrix = np.bincount(
            indices,
            minlength=self.num_classes ** 2,
        ).reshape(
            self.num_classes,
            self.num_classes
        )

        self.confusion_matrix += matrix

    def compute(self):

        cm = self.confusion_matrix.astype(np.float64)

        true_positive = np.diag(cm)

        ground_truth = cm.sum(axis=1)
        predicted = cm.sum(axis=0)

        false_positive = predicted - true_positive
        false_negative = ground_truth - true_positive

        total = cm.sum()

        pixel_accuracy = (
            true_positive.sum() / total
            if total > 0
            else np.nan
        )

        # IoU
        iou_denominator = (
            true_positive
            + false_positive
            + false_negative
        )

        per_class_iou = np.full(
            self.num_classes,
            np.nan
        )

        valid_iou = iou_denominator > 0

        per_class_iou[valid_iou] = (
            true_positive[valid_iou]
            / iou_denominator[valid_iou]
        )

        # Dice
        dice_denominator = (
            2 * true_positive
            + false_positive
            + false_negative
        )

        per_class_dice = np.full(
            self.num_classes,
            np.nan
        )

        valid_dice = dice_denominator > 0

        per_class_dice[valid_dice] = (
            2 * true_positive[valid_dice]
            / dice_denominator[valid_dice]
        )

        # Precision
        precision_denominator = (
            true_positive + false_positive
        )

        per_class_precision = np.full(
            self.num_classes,
            np.nan
        )

        valid_precision = precision_denominator > 0

        per_class_precision[valid_precision] = (
            true_positive[valid_precision]
            / precision_denominator[valid_precision]
        )

        # Recall
        recall_denominator = (
            true_positive + false_negative
        )

        per_class_recall = np.full(
            self.num_classes,
            np.nan
        )

        valid_recall = recall_denominator > 0

        per_class_recall[valid_recall] = (
            true_positive[valid_recall]
            / recall_denominator[valid_recall]
        )

        return {
            "pixel_accuracy": float(pixel_accuracy),
            "miou": float(np.nanmean(per_class_iou)),
            "dice": float(np.nanmean(per_class_dice)),
            "precision": float(
                np.nanmean(per_class_precision)
            ),
            "recall": float(
                np.nanmean(per_class_recall)
            ),
            "per_class_iou": per_class_iou,
            "per_class_dice": per_class_dice,
            "confusion_matrix": self.confusion_matrix.copy(),
        }
